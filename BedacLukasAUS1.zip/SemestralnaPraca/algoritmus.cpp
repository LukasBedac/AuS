#include "algoritmus.h"
